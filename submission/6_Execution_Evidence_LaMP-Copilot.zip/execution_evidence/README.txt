LaMP-Copilot: execution evidence

sandbox_execution_trace.log    The full demo story run against the real API (scripts/demo_run.py):
                               photo capture, forecast, return claim, smaller order, request for more
                               days, consent, loan application, duplicate-financing refusal, lender
                               decision and payout. One line per event, with its permission tier.
sandbox_execution_trace.jsonl  The same events as JSON, each hash-chained to the one before
                               (re-check with GET /api/v1/logs/verify).
results.md                     Photo-reading evaluation: 27 synthetic invoices and sales-book pages.
intent_results.md / .json      Chat intent evaluation: 20 owner questions, 20 of 20 right.
redteam_results.md / .json     Red-team evaluation: 26 of 26 attacks held.
shelf_life_sim.md              Shelf-life credit simulation behind the lending rule.

Lenders, payouts and supplier replies are sandbox partners. No real money moves.
